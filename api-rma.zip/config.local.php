<?php
return [
        'rma' => [
            'host' => '162.220.10.11',
            'port' => '3306',
            'database' => 'dosisma_rma_bd',
            'user' => 'dosisma_rma',
            'password' => 'tesis2026bruno'
        ],
        'inventario' => [
            'host' => '162.220.10.11',
            'port' => '3306',
            'database' => 'dosisma_inventario_db',
            'user' => 'dosisma_stock',
            'password' => 'inventariobrunorma2k26'
        ]
    ];
